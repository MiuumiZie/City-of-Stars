# Scene 1

A Pen created on CodePen.

Original URL: [https://codepen.io/lizzie-taran/pen/OPMvgxb](https://codepen.io/lizzie-taran/pen/OPMvgxb).

